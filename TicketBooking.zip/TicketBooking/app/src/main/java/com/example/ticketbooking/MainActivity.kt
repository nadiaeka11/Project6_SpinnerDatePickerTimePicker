package com.example.ticketbooking

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ticketbooking.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    //Mendeklarasi variabel binding untuk mengikat elemen tampilan pada layout activity_main
    private lateinit var binding: ActivityMainBinding
    private lateinit var ticket: Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ticket=resources.getStringArray(R.array.ticket)

        with(binding){
            val adapterTicket = ArrayAdapter(this@MainActivity,
                android.R.layout.simple_spinner_item, ticket)

            adapterTicket.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            ticketSpinner.adapter = adapterTicket
        }

        binding.pesanButton.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View) {
                val selectedTicket = binding.ticketSpinner.selectedItem.toString()

                // Mendapatkan tanggal yang dipilih dari DatePicker melalui Data Binding
                val year = binding.datePicker.year
                val month = binding.datePicker.month
                val dayOfMonth = binding.datePicker.dayOfMonth

                // Mendapatkan waktu yang dipilih dari TimePicker melalui Data Binding
                val hourOfDay = binding.timePicker.hour
                val minute = binding.timePicker.minute

                // Membuat format tanggal dan waktu
                val dateFormat = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault())
                val calendar = Calendar.getInstance()
                calendar.set(year, month, dayOfMonth, hourOfDay, minute)
                val dateTime = dateFormat.format(calendar.time)

                // Menampilkan pesan konfirmasi
                val confirmationMessage =
                    "Anda telah memesan tiket pada tanggal dan waktu: $dateTime dengan jenis tiket: $selectedTicket"
                val alertDialog = AlertDialog.Builder(this@MainActivity)
                    .setTitle("Konfirmasi Pemesanan")
                    .setMessage(confirmationMessage)
                    .setPositiveButton("OK") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .create()

                alertDialog.show()
            }
        })
    }
}

